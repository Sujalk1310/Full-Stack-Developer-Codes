def area_of_rectangle(length, breadth):
    return length * breadth

def area_of_circle(radius):
    return 2 * (22 / 7) * radius